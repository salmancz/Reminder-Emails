# Sending Reminder Emails

This project is about automating email reminders.

## Problem Statement

This presentation proposes implementation and use cases for sending reminder emails. Why emails are important? It can drive traffic to our website and make our customers engage with us. There are 4 billion active email users in the world. Now a days everything can be automated using different softwares but why we write email manually every time for everyone before event start? This program helps you send reminder emails for a group of users or customers with a single click. But why we using this? It’s because It’s more efficient than writing email manually for every users. This is a starter module than can be used in big companies for email marketing and improve engagement with customers. It can be used in our future company to send emails to a group of people. It’s more important to create and manage email lists for targeted audience and to achieve company success.

## Packages Used

- Streamlit
- Smtplib
- Csv
